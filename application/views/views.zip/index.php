<!DOCTYPE html>
<html lang="en">

<head>

  <?php $this->load->view('head'); ?>

</head>

 <body id="top">

  <!--[if lt IE 8]>
  <p>You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->

  <header class="header header-shrink header-inverse fixed-top">
    <?php $this->load->view('header'); ?>
  </header> <!-- END header-inverse -->

  <?php $this->load->view($content); ?>

  

  <div class="scroll-top bg-white box-shadow-v1">
  	<i class="fa fa-angle-up" aria-hidden="true"></i>
  </div>
  <?php $this->load->view('script'); ?>
  </body>

</html>
