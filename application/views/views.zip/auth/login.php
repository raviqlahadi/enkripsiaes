<section   class="u-h-100vh u-flex-center" style="background-color: #0F81FD;background-size:cover; background-position: top center;">
  <div class="container">

    <div class="row">
    	<div class="col-lg-5 m-auto text-center">
			 <div class="card box-shadow-v2 bg-white u-of-hidden">
			 	<h2 class="bg-primary m-0 py-3 text-white">Login</h2>
			 		<div class="p-4 p-md-5">
          <?php if (isset($status)): ?>
            <p style="color:#1981FB"><?php echo $status ?></p>
          <?php endif; ?>
					<form action="<?php echo site_url('auth/cek_user') ?>" method="POST">
						<div class="input-group u-rounded-50 border u-of-hidden u-mb-20">
							<div class="input-group-addon bg-white border-0 pl-4 pr-0">
								<span class="icon icon-User text-primary"></span>
							</div>
							<input type="email" name="user_email" class="form-control border-0 p-3" placeholder="Your Email">
						</div>

						<div class="input-group u-rounded-50 border u-of-hidden u-mb-20">
							<div class="input-group-addon bg-white border-0 pl-4 pr-0">
								<span class="icon icon-Key text-primary"></span>
							</div>
							<input type="password" name="user_password" class="form-control border-0 p-3" placeholder="Your Password">
						</div>
            <!--
							<div class="d-flex justify-content-between align-items-center">
								<label class="custom-control custom-checkbox text-left">
									<input type="checkbox" class="custom-control-input">
									<span class="custom-control-indicator mt-1"></span>
									<span class="custom-control-description">Remember me</span>
								</label>
								<a href="#">Forgot password?</a>
							</div>
            -->
							<button class="btn btn-primary btn-rounded u-mt-20 u-w-170">
								Login
							</button>
					</form>
          <br>
					<p>
						Belum punya akun? silahkan <a href="<?php echo site_url('auth/register') ?>" class="text-primary">Register</a>
					</p>
			 		</div> <!-- END p-4 p-md-5-->
			 </div>  <!-- END card-->
     </div> <!-- END col-lg-5-->
    </div> <!-- END row-->
  </div> <!-- END container-->

</section> <!-- END intro-hero-->
