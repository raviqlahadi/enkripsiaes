<!--Meta-->
<meta charset="UTF-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="A complete landing page solution for any business">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!--Favicon-->
<link rel="icon" href="<?php echo base_url()?>assets/img/favicon/144x144.png">

<!-- Title-->
<title>Jurusanet</title>

<!--Google fonts-->
<link href="<?php echo base_url()?>https://fonts.googleapis.com/css?family=Dosis:400,500,600,700%7COpen+Sans:400,600,700" rel="stylesheet">

<!--Icon fonts-->
<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/strokegap/style.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/linearicons/style.css">

<!-- Stylesheet-->
<!--
// ////////////////////////////////////////////////
// To Reduce server request and improved page speed drastically all third-party plugin bundle in assets/css/bundle.css
// If you wanna add those manually bellow is the sequence
// ///////////////////////////////////////////////
-->
<!--  <link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/slick-carousel/slick/slick.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/fancybox/dist/jquery.fancybox.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/animate.css/animate.min.css">-->

<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bundle.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js" charset="utf-8"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/locale/id.js" charset="utf-8"></script>
