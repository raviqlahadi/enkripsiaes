<section class="u-py-100 u-pt-lg-200 u-pb-lg-150 u-flex-center" style="
background: #56CCF2;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #2F80ED, #56CCF2);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #2F80ED, #56CCF2); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

  background-repeat: repeat-x;
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#FF8B3AC6', endColorstr='#FF4D3399', GradientType=1);
  ">

  <div class="container">
    <div class="row">
    	<div class="col-12 text-center text-white">
    		<h1 class="text-white">
    			Daftar Jurusan
    		</h1>
    		<div class="u-h-4 u-w-50 bg-white rounded mx-auto my-4"></div>
    		<p class="lead">
    			Pilih Kategori Kunci Karir Untuk Melihat Kelompok Jurusan
    		</p>
    	</div>
    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END intro-hero-->




<section>
  <div class="container">

    <div class="row">
      <div class="col-sm-12 text-center my-4">
        <ul class="portfolio-filter list-inline box-shadow-v1 d-inline-block">
          <li class="list-inline-item active" data-filter="*">Semua Jurusan</li>
          <?php
              $arrKunic = array(
                'realistik',
                'investigasi',
                'artistik',
                'sosial',
                'enterpreneur',
                'konvensional'
              );
           ?>
           <?php foreach ($arrKunic as $k): ?>
               <li class="list-inline-item" data-filter=".<?php echo $k ?>"><?php echo ucfirst($k) ?></li>
           <?php endforeach; ?>

        </ul>
      </div>
    </div> <!-- END row-->

    <div class="row portfolio" data-init="img-gallery">
      <?php foreach ($jurusan as $key => $value): ?>
        <div class="col-md-6 col-lg-4 portfolio-item <?php echo strtolower($value->tipekarir_name)?>">
          <div class="card border-0 box-shadow-v3 u-h-100p">
            <?php if ($value->jurusan_image!=null): ?>
              <img src="uploads/jurusan/<?php echo $value->jurusan_image ?>" alt="">
            <?php else: ?>
              <img src="<?php echo base_url() ?>assets/no_image.png" alt="">
            <?php endif; ?>
          <div class="u-p-30">
            <h4>
              <?php echo $value->jurusan_name ?>
            </h4>
            <p class="d-flex text-muted">
              <span><i class="icon icon-Key mr-1"></i> <?php echo $value->tipekarir_name ?></span>

            </p>
            <p>
              <?php echo $value->jurusan_learn ?>
            </p>
            <a href="<?php echo site_url('home/jurusan_detail?id='.$value->jurusan_id) ?>" class="btn btn-primary btn-rounded my-3">
              Baca Lebih Lanjut
            </a>
          </div>
          </div> <!-- END card-->
        </div> <!--  END col-md-4-->
      <?php endforeach; ?>

    </div> <!-- END row-->

  </div> <!-- END container-->
</section> <!-- END portfolio-->

<footer style="background:url(<?php echo base_url()?>assets/img/app/footer.jpg) no-repeat; background-size: cover; background-position: center center; padding-top: 200px">
  <?php $this->load->view('footer'); ?>
</footer> <!-- END footer-->
