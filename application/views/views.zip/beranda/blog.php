<section style="max-height:100px" class="u-py-100 u-h-100vh u-flex-center" data-dark-overlay="6" data-parallax ="<?php echo base_url('uploads/img/'.$blog_data->post_image) ?>">
  <div class="container">
    <div class="row">
    	<div class="col-12 text-center text-white">
    		<h1 class="text-white">
    			<?php echo $blog_data->post_title ?>
    		</h1>
    	</div>
    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END intro-hero-->





<section class="pt-5">
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<article class="blog-details">
					<img src="assets/img/blog/1_1.jpg" alt="">
					<h2 class="post-title mt-4">
						<?php echo $blog_data->post_title ?>
					</h2>
				<div class="post-meta">
          <span id='date' class="text-mute"></span>
					<script type="text/javascript">
            let date = document.getElementById('date');
            date.innerHTML = moment('<?php echo substr($blog_data->post_date,0,10) ?>','YYYY-mm-dd').format('Do MMMM  YYYY');
          </script>
				</div>
					<?php echo $blog_data->post_content ?>
        </article>
        <!--
        <div class="my-5">

          <h4>2 Comments</h4>

          <hr>

  				<div class="media mt-5">
  					<img class="mr-3 rounded-circle u-w-60" src="assets/img/person/1.jpg" alt="">
  					<div class="media-body">
  						<h5 class="mt-0">Jonathon</h5>
  							<span>Says August 15, 2017 at 11:33PM</span>
  							<p>
  								Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
  							</p>

  						<div class="media mt-5">
  							<img class="mr-3 rounded-circle u-w-60" src="assets/img/person/2.jpg" alt="">
  							<div class="media-body">
  								<h5 class="mt-0">Andy</h5>
  								<span>Says August 15, 2017 at 11:33PM</span>
  								<p>
  									Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
  								</p>
  							</div>
  						</div>
  					</div>
  				</div>

  				<div class="media mt-5">
  						<img class="mr-3 rounded-circle u-w-60" src="assets/img/person/3.jpg" alt="">
  						<div class="media-body">
  							<h5 class="mt-0">Bryson</h5>
  							<span>Says August 15, 2017 at 11:33PM</span>
  							<p>
  								Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
  							</p>
  						</div>
  					</div>
        </div>

        <h4 class="mb-4">Leave Your Comments</h4>
				<form action="#" method="POST">
					<div class="row">
						<div class="col-md-6">
							<input type="text" class="form-control u-rounded-50 p-3 u-mb-30" placeholder="Name" required>
						</div>
						<div class="col-md-6">
							<input type="text" class="form-control u-rounded-50 p-3 u-mb-30" placeholder="Your email" required>
						</div>
					</div>
					<textarea class="form-control u-rounded-15 p-3 u-mb-30" rows="6" placeholder="Youe text..." required></textarea>
					<button class="btn btn-rounded btn-primary u-w-170" type="submit">Submit</button>
				</form>
          -->
			</div>

			<aside id="sidebar" class="col-lg-4">

			 	<div class="widget sidebar-widget">
           <h2 class="sidebar-widget-title">Search For</h2>
          <div class="widget-content">
					 <div class="input-group u-rounded-50 border u-of-hidden u-mb-20">
							<div class="input-group-addon bg-white border-0 pl-4 pr-0">
								<span class="icon icon-Search text-primary"></span>
							</div>
							<input type="text" class="form-control border-0 p-3" placeholder="Type & hit enter">
						</div>
          </div>
        </div> <!-- END sidebar-widget-->

        <div class="sidebar-widget">
          <div class="tag-cloud">
            <h2 class="sidebar-widget-title">Tags</h2>
            <?php $tags = explode("#",$blog_data->post_kategori)?>

            <div class="widget-content tags-list">
              <?php foreach (array_filter($tags) as $key => $value): ?>
              
                <?php if ($value!="" || $value!=" "): ?>
                  <a href="#"><?php echo $value ?></a>
                <?php endif; ?>

              <?php endforeach; ?>


            </div>
         </div> <!-- END tag-cloud-->
        </div> <!-- END sidebar-widget-->

      </aside>
		</div> <!-- END row-->
	</div>	 <!-- END container-->
</section> <!-- END section-->

<footer style="background:url(<?php echo base_url()?>assets/img/app/footer.jpg) no-repeat; background-size: cover; background-position: center center; padding-top: 200px">
  <?php $this->load->view('footer'); ?>
</footer> <!-- END footer-->
