

<section class="u-py-100 u-pt-lg-200 u-pb-lg-150 u-flex-center" style="background: #56CCF2;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #2F80ED, #56CCF2);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #2F80ED, #56CCF2); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

 background-repeat: repeat-x;
 filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#FF8B3AC6', endColorstr='#FF4D3399', GradientType=1);">

 <div class="container">
   <div class="row">
     <div class="col-12 text-center text-white">
       <h1 class="text-white">
         Informasi Terbaru
       </h1>
       <div class="u-h-4 u-w-50 bg-white rounded mx-auto my-4"></div>
       <p class="lead">
         Dapatkan informasi terbaru seputar pemilihan jurusan dan penentuan karir
       </p>
     </div>
   </div> <!-- END row-->
 </div> <!-- END container-->
</section> <!-- END intro-hero-->





<section class="py-5">
 <div class="container">
   <div class="row">
     <div class="col-lg-8">
       <?php foreach ($blog_data as $key => $value): ?>
         <article class="post box-shadow-v2">
           <div class="post__img">
             <img src="<?php echo base_url('uploads/img/').$value->post_image ?>" alt="">
           </div>
           <div class="post__content">
           <div class="post__date box-shadow-v2 d-inline-block text-center px-2 px-md-4 py-2 rounded">
             <h4 class="u-fs-20 u-fs-md-36"><span class="text-primary"> <?php echo substr($value->post_date,8,2) ?></span> <span class="d-block u-fs-16"><span id='bulan_<?php echo $value->post_id; ?>'></span> <?php echo substr($value->post_date,0,4) ?></span></h4>
             <script type="text/javascript">
                let bulan_<?php echo $value->post_id; ?> = document.getElementById('bulan_<?php echo $value->post_id; ?>' );
                bulan_<?php echo $value->post_id; ?>.innerHTML = moment().month(<?php echo substr($value->post_date,6,1) ?>).format("MMM");

             </script>
           </div>
           <div class="post__share">
             <span class="icon icon-Share bg-white box-shadow-v2 share__icon"></span>
             <div class="post__share-media">
               <a data-js="facebook-share">
                 <i class="fa fa-facebook bg-facebook text-white share__icon"></i>
               </a>
               <a data-js="twitter-share">
                 <i class="fa fa-twitter bg-twitter text-white share__icon"></i>
               </a>
             </div>
           </div>
             <h2 class="post__title">
              <?php echo $value->post_title ?>
             </h2>
             <ul class="list-inline u-my-20">
               <li class="list-inline-item mr-3">
                 <a href="#">By <strong><?php echo ucfirst($value->user_name) ?></strong> </a>
               </li>
               <li class="list-inline-item mr-3">
                 <a href="">in <strong><?php echo $value->post_kategori; ?></strong> </a>
               </li>
             </ul>
             <p>
               <?php
               $str = $value->post_content;
               if (strlen($str) > 10)
                $str = substr($str, 0, 300) . '...';
               echo $str;
               ?>
             </p>
             <a href="<?php echo site_url('home/blog?id='.$value->post_id) ?>" class="btn btn-rounded btn-primary u-mt-20">Lanjutkan Membaca</a>
           </div>
         </article> <!-- END post-->
       <?php endforeach; ?>



     </div> <!-- END col-lg-8 -->
     <aside id="sidebar" class="col-lg-4">

       <div class="widget sidebar-widget">
          <h2 class="sidebar-widget-title">Pencarian</h2>
         <div class="widget-content">
          <div class="input-group u-rounded-50 border u-of-hidden u-mb-20">
             <div class="input-group-addon bg-white border-0 pl-4 pr-0">
               <span class="icon icon-Search text-primary"></span>
             </div>
             <input type="text" class="form-control border-0 p-3" placeholder="Type & hit enter">
           </div>
         </div>
       </div> <!-- END sidebar-widget-->



       <div class="sidebar-widget">
         <div class="tag-cloud">
           <h2 class="sidebar-widget-title">popular tags</h2>
           <div class="widget-content tags-list">
             <a href="#">Fashion</a>
             <a href="#">Audio</a>
             <a href="#">Lifestyle</a>
             <a href="#">Travel</a>
             <a href="#">Food</a>
             <a href="#">Products</a>
             <a href="#">Education</a>
             <a href="#">envato</a>
             <a href="#">UI UX</a>
             <a href="#">WordPress</a>
             <a href="#">Blogging</a>
           </div>
        </div> <!-- END tag-cloud-->
       </div> <!-- END sidebar-widget-->

     </aside>
   </div> <!-- END row-->
 </div>	 <!-- END container-->
</section> <!-- END section-->

<footer style="background:url(<?php echo base_url()?>assets/img/app/footer.jpg) no-repeat; background-size: cover; background-position: center center; padding-top: 200px">
  <?php $this->load->view('footer'); ?>
</footer> <!-- END footer-->
<script type="text/javascript">
    var twitterShare = document.querySelector('[data-js="twitter-share"]');

    twitterShare.onclick = function(e) {
    e.preventDefault();
    var twitterWindow = window.open('https://twitter.com/share?url=' + document.URL, 'twitter-popup', 'height=350,width=600');
    if(twitterWindow.focus) { twitterWindow.focus(); }
      return false;
    }

    var facebookShare = document.querySelector('[data-js="facebook-share"]');

    facebookShare.onclick = function(e) {
    e.preventDefault();
    var facebookWindow = window.open('https://www.facebook.com/sharer/sharer.php?u=' + document.URL, 'facebook-popup', 'height=350,width=600');
    if(facebookWindow.focus) { facebookWindow.focus(); }
      return false;
    }
</script>
