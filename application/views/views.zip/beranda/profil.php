
<section class="u-py-100 u-h-100vh u-flex-center bg-blue">
  <div class="container">
    <div class="row align-items-center">

      <div class="col-lg-6">
        <div class="row">
      <div class="col-12 u-mt-80 ">
        <h1 class="display-4 u-fw-600 text-white u-mb-40">
          Anda Bertipe <span style="font-weight:bolder;color:#feffc3"><?php echo $karir_result->tipekarir_name ?></span>
        </h1>
        <p class="text-white u-lh-1_8 u-mb-40">
          <?php echo $karir_result->tipekarir_description ?>
        </p>

      </div> <!-- END col-lg-6-->
    </div> <!-- END row-->
      </div> <!-- END col-lg-6 ml-auto-->
      <div class="col-lg-6 mb-4 mr-auto" style="padding:50px">
        <div class="row bg-white box-shadow-v2 rounded py-5">
          <div class="col-md-6 my-4">
            <?php if ($userdata->user_sex=="Perempuan"): ?>
              <img class="w-100 rounded box-shadow-v1" src="<?php echo base_url() ?>assets/img/perempuan.png" alt="">
            <?php else: ?>
              <img class="w-100 rounded box-shadow-v1" src="<?php echo base_url() ?>assets/img/laki_laki.png" alt="">
            <?php endif; ?>

          </div>
          <div class="col-md-6 my-4 py-5">
            <h2 class="mb-0">
              <?php echo ucfirst($userdata->user_name) ?>
            </h2>
            <p class="text-muted mb-0">
              <?php echo $userdata->user_email ?>
            </p>
          </div>
        </div> <!-- END row-->

      </div> <!-- END col-lg-6 pl-lg-5 -->

    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END intro-hero-->
<section id="blog">
 	<div class="container">

   <div class="row">
     <div class="col-lg-6 m-auto text-center">
       <h2 class="h1">
         Saran Jurusan
       </h2>
       <div class="u-h-4 u-w-50 bg-primary rounded mt-4 u-mb-40 mx-auto"></div>
     </div>
   </div> <!--END row-->

   <div class="row portfolio" data-init="img-gallery">
     <?php foreach ($jurusan as $key => $value): ?>
       <div class="col-md-6 col-lg-4 portfolio-item <?php echo strtolower($value->tipekarir_name)?>">
         <div class="card border-0 box-shadow-v3 u-h-100p">
           <?php if ($value->jurusan_image!=null): ?>
             <img src="uploads/jurusan/<?php echo $value->jurusan_image ?>" alt="">
           <?php else: ?>
             <img src="<?php echo base_url() ?>assets/no_image.png" alt="">
           <?php endif; ?>
         <div class="u-p-30">
           <h4>
             <?php echo $value->jurusan_name ?>
           </h4>
           <p class="d-flex text-muted">
             <span><i class="icon icon-Key mr-1"></i> <?php echo $value->tipekarir_name ?></span>

           </p>
           <p>
             <?php echo $value->jurusan_learn ?>
           </p>
           <a href="<?php echo site_url('home/jurusan_detail?id='.$value->jurusan_id) ?>" class="btn btn-primary btn-rounded my-3">
             Baca Lebih Lanjut
           </a>
         </div>
         </div> <!-- END card-->
       </div> <!--  END col-md-4-->
     <?php endforeach; ?>

   </div> <!-- END row-->
   
 	</div> <!-- END container-->
 </section>

<footer style="background:url(<?php echo base_url()?>assets/img/app/footer.jpg) no-repeat; background-size: cover; background-position: center center; padding-top: 200px">
  <?php $this->load->view('footer'); ?>
</footer> <!-- END footer-->
