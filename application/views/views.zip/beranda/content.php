<section class="u-py-100 u-h-100vh u-flex-center" style="background:url(<?php echo site_url()?>assets/img/seo/hero-banner.jpg) no-repeat; background-size:cover; background-position: top center;">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 u-mt-80">
        <h1 class="display-4 u-fw-600 text-white u-mb-40">
          Good  choice today, best future tomorrow
        </h1>
        <p class="u-fs-22 text-white u-lh-1_8 u-mb-40">
            Jurusanet Dapat Membantu Anda Menentukan Pilihan Akademik Anda
          </p>
        <a href="<?php echo base_url()?>#" class="btn btn btn-rounded btn-green  px-md-5">
          Mulai Test
        </a>
        <a href="<?php echo base_url()?>#" class="btn btn btn-rounded btn-white ml-3 px-md-5">
          Pelajari Lebih Lanjut
        </a>
      </div> <!-- END col-lg-6-->
      <div class="col-lg-6 u-mt-80 text-center">
        <img src="<?php echo site_url() ?>assets/img/college.png" alt="">
        <!---
        <ul class="p-0" data-init="carousel" data-slick='{ "slidesToShow":1, "dots":true, "arrows":false, "dotsClass":"slick-dots dots-white mt-4 text-center"}'>
          <li>
            <img class="box-shadow-v1" src="<?php echo site_url() ?>assets/img/seo/s-1.png" alt="">
          </li>
          <li>
            <img class="box-shadow-v1" src="<?php echo site_url() ?>assets/img/seo/s-1.png" alt="">
          </li>
          <li>
            <img class="box-shadow-v1" src="<?php echo site_url() ?>assets/img/seo/s-1.png" alt="">
          </li>
        </ul>
        -->
      </div> <!-- END col-lg-6-->
    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END intro-hero-->

<section id="features">
  <div class="container">
    <div class="row text-center">

      <div class="col-md-4 u-mt-30">
        <div class="bg-white px-5 u-py-50 u-h-100p rounded box-shadow-v2">
          <img class="u-w-100" src="<?php echo site_url() ?>assets/img/svg/information.svg" alt="">
          <h4 class="u-fs-26 u-my-35">
            Halaman Informasi
          </h4>
          <p class="mb-0">
              Halaman informasi berisi tentang berbagai artikel seputar perguruan tinggi
          </p>
        </div>
      </div> <!-- END col-md-4-->

      <div class="col-md-4 u-mt-30">
        <div class="bg-white px-5 u-py-50 u-h-100p rounded box-shadow-v2">
          <img class="u-w-100" src="<?php echo site_url() ?>assets/img/svg/graduation.svg" alt="">
          <h4 class="u-fs-26 u-my-35">
            Jurusan
          </h4>
          <p class="mb-0">
            Halaman jurusan berisi tentang daftar jurusan berdasarkan kategori kepribadian/minat dari kunci karir Holland
          </p>
        </div>
      </div> <!-- END col-md-4-->

      <div class="col-md-4 u-mt-30">
        <div class="bg-white px-5 u-py-50 u-h-100p rounded box-shadow-v2">
          <img class="u-w-100" src="<?php echo site_url() ?>assets/img/svg/key.svg" alt="">
          <h4 class="u-fs-26 u-my-35">
            Kunci Karir
          </h4>
          <p class="mb-0">
            Halaman kunci karir berisi tentang inventori Holland untuk mengetahui potensi karir melalui tipe kepribadian/minatnya.
          </p>
        </div>
      </div> <!-- END col-md-4-->
    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END section-->

<section class="bg-gray-v2">
  <div class="container">
   <div class="row">
     <div class="col-lg-6 m-auto text-left">
       <h2 class="h1">
          Jurusanet Adalah
       </h2>
       <hr>
       <p class="text-left">
          Website jususanet ini akan membantumu untuk membuat keputusan mengenai studi lanjut ke perguruan tinggi. Bukan untuk memilih satu jurusan untuk kamu, tapi untuk menunjukkan berbagai alternatif jurusan yang mungkin sesuai dengan potensi yang kamu miliki.
        </p>
        <!--
       <div class="row">
        <div class="col-md-4 mt-5">
          <h4 class="u-fs-48 u-fw-400 text-green mb-0">260</h4>
          <p class="u-fs-20 u-ff-dosis">Countries</p>
        </div>
        <div class="col-md-4 mt-5">
          <h4 class="u-fs-48 u-fw-400 text-green mb-0">2590</h4>
          <p class="u-fs-20 u-ff-dosis">Online Strategies</p>
        </div>
        <div class="col-md-4 mt-5">
          <h4 class="u-fs-48 u-fw-400 text-green mb-0">98k</h4>
          <p class="u-fs-20 u-ff-dosis">Highest Rankings</p>
        </div>
       </div>
         -->
     </div> <!-- END col-lg-8-->

     <div class="col-6 u-mt-80 text-center">
      <img src="<?php echo site_url() ?>assets/img/seo/s-2.png" alt="">
     </div>
   </div> <!--END row-->
  </div> <!-- END container-->
</section> <!-- END section-->

<section id="features" class="bg-gray-v1">
  <div class="container">
    <div class="row text-center">

     <div class="col-12">
       <h2 class="h1">
        Apa Saja Yang Ada Di Jurusanet?
       </h2>
       <div class="u-h-4 u-w-50 bg-primary rounded mt-4 u-mb-40 mx-auto"></div>
     </div>

      <div class="col-lg-4 col-md-6 u-mt-30">
        <div class="bg-white px-4 py-5 px-md-5 u-h-100p rounded box-shadow-v1">
          <div class="u-w-90 u-h-90 u-flex-center bg-green text-white rounded-circle m-auto">
            <span class="icon icon-Tools u-fs-42"></span>
          </div>
          <h4 class="u-fs-26 u-pt-30 u-pb-20">
            Mengenal Perguruan Tinggi
          </h4>
          <p>

          </p>
        </div>
      </div> <!-- END col-lg-4 col-md-6-->

      <div class="col-lg-4 col-md-6 u-mt-30">
        <div class="bg-white px-4 py-5 px-md-5 u-h-100p rounded box-shadow-v1">
          <div class="u-w-90 u-h-90 u-flex-center bg-primary text-white rounded-circle m-auto">
            <span class="icon icon-Starship2 u-fs-42"></span>
          </div>
          <h4 class="u-fs-26 u-pt-30 u-pb-20">
            Sarjana atau Diploma
          </h4>
          <p>

          </p>
        </div>
      </div> <!-- END col-lg-4 col-md-6-->

      <div class="col-lg-4 col-md-6 u-mt-30">
        <div class="bg-white px-4 py-5 px-md-5 u-h-100p rounded box-shadow-v1">
          <div class="u-w-90 u-h-90 u-flex-center bg-yellow text-white rounded-circle m-auto">
            <span class="icon icon-MessageLeft u-fs-42"></span>
          </div>
          <h4 class="u-fs-26 u-pt-30 u-pb-20">
            Jalur Masuk ke Perguruan Tinggi
          </h4>
          <p>

          </p>
        </div>
      </div> <!-- END col-lg-4 col-md-6-->
      <div class="col-lg-2"></div>
      <div class="col-lg-4 col-md-6 u-mt-30">
        <div class="bg-white px-4 py-5 px-md-5 u-h-100p rounded box-shadow-v1">
          <div class="u-w-90 u-h-90 u-flex-center bg-primary text-white rounded-circle m-auto">
            <span class="icon icon-Notebook u-fs-42"></span>
          </div>
          <h4 class="u-fs-26 u-pt-30 u-pb-20">
            Kiat-Kiat Memilih Jurusan
          </h4>
          <p>

          </p>
        </div>
      </div> <!-- END col-lg-4 col-md-6-->

      <div class="col-lg-4 col-md-6 u-mt-30">
        <div class="bg-white px-4 py-5 px-md-5 u-h-100p rounded box-shadow-v1">
          <div class="u-w-90 u-h-90 u-flex-center bg-red text-white rounded-circle m-auto">
            <span class="icon icon-Bulb u-fs-42"></span>
          </div>
          <h4 class="u-fs-26 u-pt-30 u-pb-20">
            Daftar Jurusan Favorit
          </h4>
          <p>

          </p>
        </div>
      </div> <!-- END col-lg-4 col-md-6-->


    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END section-->

<footer style="background:url(<?php echo base_url()?>assets/img/app/footer.jpg) no-repeat; background-size: cover; background-position: center center; padding-top: 200px">
  <?php $this->load->view('footer'); ?>
</footer> <!-- END footer-->
