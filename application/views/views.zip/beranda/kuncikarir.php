<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="colorlib.com">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="<?php echo base_url('assets/kuncikarir/')?>fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/kuncikarir/')?>css/style.css">
    <style media="screen">
      .content{
        height: auto!important;
      }
      .question-box{
        width:100%;
        padding-left:40px;
      }
      .radio {
        width:20px!important;
        display:inline!important;
        height:auto!important;
      }
      .figure {
        height: 100%;
        width: 100%;

      }
      .figure figure{
        position: fixed;
        top: 220px;

      }


    </style>
</head>

<body>

    <div class="main">

        <div class="container">
            <form method="POST" id="signup-form" action="<?php echo site_url('kuncikarir/submit') ?>" class="signup-form" enctype="multipart/form-data">
              <?php $no=1 ?>
              <h3></h3>
                <fieldset>
                    <span class="step-current"> <span class="step-current-content"><span class="step-number"><span>Info</span></span></span> </span>
                    <div class="fieldset-flex">
                        <figure>
                            <img style="width:350px"src="<?php echo site_url() ?>assets/img/college.png" alt="">
                        </figure>
                        <div class="fieldset-content">
                            <h2>Kunci Karir</h2>
                            <p>
                              Kunci karir adalah teori karir dari John Holland untuk mengetahui potensi karir seseorang berdasarkan minatnya. Menurut Holland orang-orang dan lingkungan kerja dapat digolongkan ke dalam enam kategori kepribadian yaitu realistik, investigatif, artistik, sosial, enterperneur, dan konvensional.

                            </p>
                            <p>
                               Kebanyakan orang dapat memiliki kombinasi dari tiga tipe kepribadian atau minat. Sebagai contoh, seorang petani mungkin realistik (R), konvensional (C), dan investigatif (I). Untuk mengetahui minatmu, kamu bisa menggunakan inventori berikut ini.
                            </p>
                            <p>
                              Beri tanda silang (X) pada kotak ‘S’ jika kalian MENYUKAInya, dan ‘T’ jika kalian TIDAK MENYUKAInya. Setelah selesai, hitung jumlah S dan T di masing-masing jenis atau bagian keterampilan yang ada. Keterampilan kesukaanmu adalah yang memiliki ‘S’ lebih banyak

                            </p>

                        </div>
                    </div>
                </fieldset>

              <?php foreach ($res as $key => $r): ?>
                <h3></h3>
                <fieldset>
                    <span class="step-current"> <span class="step-current-content"><span class="step-number"><span>0<?php echo $no ?></span>/0<?php echo count($res); ?></span></span> </span>
                    <div class="fieldset-flex">
                        <div class="figure">
                          <figure>
                              <img src="<?php echo base_url('assets/kuncikarir/images/kk'.$no.'.png')?>" alt="">
                          </figure>
                        </div>
                        <div class="question-box" style="">
                        <?php
                        $i = 1;
                        foreach ($r[0] as $k => $value): ?>
                          <div class="">
                              <?php $rng = rand(1,2); ?>
                              <h3 style="padding-bottom:0px!important"><?php echo $value?>?</h3>
                                <input type="radio" class="radio" <?php echo ($rng==1 ?  "checked":'') ?> name="<?php echo strtolower($key).'_'.$i ?>" value="s"  /><span>Suka</span>
                                <input type="radio" class="radio" <?php echo ($rng==2 ?  "checked":'') ?> name="<?php echo strtolower($key).'_'.$i ?>" value="t"  /><span>Tidak Suka</span>
                          </div>
                        <?php $i++; ?>
                        <?php endforeach; ?>
                        </div>

                </fieldset>
              <?php $no++; ?>
              <?php endforeach; ?>

            </form>
        </div>

    </div>

    <!-- JS -->
    <script src="<?php echo base_url('assets/kuncikarir/')?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('assets/kuncikarir/')?>vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="<?php echo base_url('assets/kuncikarir/')?>vendor/jquery-validation/dist/additional-methods.min.js"></script>
    <script src="<?php echo base_url('assets/kuncikarir/')?>vendor/jquery-steps/jquery.steps.min.js"></script>
    <script src="<?php echo base_url('assets/kuncikarir/')?>js/main.js"></script>
</body>

</html>
