<section class="u-py-100 u-h-100vh u-flex-center"
      style="
      background: #FC5C7D;  /* fallback for old browsers */
      background: -webkit-linear-gradient(to right, #6A82FB, #FC5C7D);  /* Chrome 10-25, Safari 5.1-6 */
      background: linear-gradient(to right, #6A82FB, #FC5C7D); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
      ">
  <div class="container">
    <div class="row">
    	<div class="col-12 text-center text-white">
    		<h1 class="text-white">
    			<?php echo $entry->jurusan_name ?>
    		</h1>
    	</div>
    </div> <!-- END row-->
  </div> <!-- END container-->
</section> <!-- END intro-hero-->

<section class="py-5">
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<article class="post box-shadow-v2">
						<div class="post__img">
              <?php if ($entry->jurusan_image==null): ?>
                <img src="<?php echo base_url() ?>assets/no_image_w.png" alt="">
              <?php else: ?>
                <img src="assets/img/blog/1_1.jpg" alt="">
              <?php endif; ?>

						</div>
						<div class="post__content">
						<div class="post__date box-shadow-v2 d-inline-block text-center px-2 px-md-4 py-2 rounded">
							<h4 class="u-fs-20 u-fs-md-36"><span class="text-primary"><?php echo strtoupper($entry->tipekarir_code) ?></span> <span class="d-block u-fs-16"><?php echo $entry->tipekarir_name ?></span></h4>
						</div>

							<h2 class="post__title">
								<?php echo $entry->jurusan_name ?>
							</h2>
							<p>
								<?php echo $entry->jurusan_learn ?>
							</p>
              <h4>Prospek Kerja</h4>
              <p><?php echo $entry->jurusan_job ?></p>

							<a href="<?php echo site_url('home/jurusan') ?>" class="btn btn-rounded btn-primary u-mt-20">Kembali</a>
						</div>
					</article> <!-- END post-->

				</div> <!-- END col-lg-8 -->
				<aside id="sidebar" class="col-lg-4">

          			<div class="sidebar-widget">
          			  <div class="tag-cloud">
          				<h2 class="sidebar-widget-title">Kuliah Dimana?</h2>
                  <?php
                    $jurusan = explode(',',$entry->jurusan_college);
                  ?>
          				<div class="widget-content tags-list">
                    <?php foreach ($jurusan as $key => $value): ?>
                        <a href="#"><?php echo $value ?></a>
                    <?php endforeach; ?>

          				</div>
          			 </div> <!-- END tag-cloud-->
          			</div> <!-- END sidebar-widget-->

		     </aside>
			</div> <!-- END row-->
		</div>	 <!-- END container-->
	</section> <!-- END section-->







<footer style="background:url(<?php echo base_url()?>assets/img/app/footer.jpg) no-repeat; background-size: cover; background-position: center center; padding-top: 200px">
  <?php $this->load->view('footer'); ?>
</footer> <!-- END footer-->
