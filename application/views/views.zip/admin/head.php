<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<!-- Favicon icon -->
<link rel="icon" href="<?php echo base_url()?>assets/img/favicon/144x144.png">
<title>Jurusanet</title>
<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url()?>assets/admin/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- chartist CSS -->
<link href="<?php echo base_url()?>assets/admin/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/admin/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/admin/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/admin/plugins/css-chart/css-chart.css" rel="stylesheet">
<!--This page css - Morris CSS -->
<link href="<?php echo base_url()?>assets/admin/plugins/c3-master/c3.min.css" rel="stylesheet">
<!-- Vector CSS -->
<link href="<?php echo base_url()?>assets/admin/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
<!-- Custom CSS -->
<link href="<?php echo base_url()?>assets/admin/css/style.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url()?>assets/admin/plugins/html5-editor/bootstrap-wysihtml5.css" />
<!-- You can change the theme colors from here -->
<link href="<?php echo base_url()?>assets/admin/css/colors/blue.css" id="theme" rel="stylesheet">

<script src="<?php echo base_url()?>assets/admin/plugins/jquery/jquery.min.js"></script>

<link href="<?php echo base_url()?>assets/admin/plugins/datatables/media/css/dataTables.bootstrap4.css" rel="stylesheet">


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
