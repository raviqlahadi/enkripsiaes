<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 col-8 align-self-center">
                <h3 class="text-themecolor">User</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo $parent ?>">User</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                  <h4 class="card-title">Silahkan Masukan Data User</h4>
                  <h6 class="card-subtitle">Pilih User Level <code>Admin</code> Untuk Menambahkan Admin Baru</h6>
                  <form class="form-material m-t-40" action="<?php echo $form_post;?>" method="post">
                      <div class="form-group">
                          <label>Nama User</label>
                          <input type="text" name="user_name" class="form-control form-control-line" autofocus> </div>
                      <div class="form-group">
                          <label for="example-email">Email </label>
                          <input type="email" id="example-email2" name="user_email" class="form-control" placeholder="contoh  : example@gmail.com"> </div>
                      <div class="form-group">
                          <label>Password</label>
                          <input type="password" name="user_password" class="form-control"  placeholder="Minimal 6 character"> </div>
                      <div class="form-group">
                          <label>Telepon</label>
                          <input type="text" name="user_phone" class="form-control form-control-line" placeholder="contoh +62822xxxx"> </div>
                      <div class="form-group">
                          <label>Tempat Lahir</label>
                          <input type="text" name="user_birthplace" class="form-control form-control-line"> </div>
                      <div class="form-group">
                          <label>Tanggal Lahir</label>
                          <input type="date" name="user_birthdate" class="form-control form-control-line"> </div>

                      <div class="form-group">
                          <label>Alamat</label>
                          <textarea name="user_address"class="form-control" rows="5"></textarea>
                      </div>
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <br>
                        <input name="user_sex" type="radio" id="radio_7" value="Laki-Laki" class="radio-col-blue" checked="checked">
                        <label for="radio_7">Laki-Laki</label>
                        <input name="user_sex" type="radio" id="radio_8" value="Perempuan" class="radio-col-pink">
                        <label for="radio_8">Perempuan</label>

                      </div>
                      <div class="form-group">
                          <label>User Level</label>
                          <select name="user_level" class="form-control">
                              <option value="Admin">Admin</option>
                              <option value="User">User</option>
                          </select>
                      </div>


                      <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="button">Simpan</button>
                        <button type="reset" class="btn btn-warning" name="button">Reset</button>
                      </div>
                  </form>
              </div>
            </div>
          </div>
        </div>


    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <?php $this->load->view('admin/footer'); ?>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<?php $this->load->view('admin/script_edit'); ?>
