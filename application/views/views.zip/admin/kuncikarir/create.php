<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 col-8 align-self-center">
                <h3 class="text-themecolor">Kunci Karir</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo $parent ?>">Kunci Karir</a></li>
                    <li class="breadcrumb-item active">Tambah</li>
                </ol>
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                  <h4 class="card-title">Silahkan Masukan Data Kunci Karir</h4>
                  <h6 class="card-subtitle">Pilih Kunci Karir Level <code>Admin</code> Untuk Menambahkan Admin Baru</h6>
                  <form class="form-material m-t-40" action="<?php echo $form_post;?>" method="post">
                      <div class="form-group">
                          <label>Pertanyaan</label>
                          <input type="text" name="kuncikarir_question" class="form-control form-control-line" autofocus> </div>

                      <div class="form-group">
                          <label>Tipe</label>
                          <select name="tipekarir_id" class="form-control">
                              <?php foreach ($tipekarir as $key => $value): ?>
                                <option value="<?php echo $value->tipekarir_id ?>"><?php echo $value->tipekarir_name ?></option>
                              <?php endforeach; ?>
                          </select>
                      </div>


                      <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="button">Simpan</button>
                        <button type="reset" class="btn btn-warning" name="button">Reset</button>
                      </div>
                  </form>
              </div>
            </div>
          </div>
        </div>


    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <?php $this->load->view('admin/footer'); ?>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
