<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 col-8 align-self-center">
                <h3 class="text-themecolor">Post</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo $parent ?>">Post</a></li>
                    <li class="breadcrumb-item active"><?php echo $form_value->post_title ?></li>
                </ol>
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
          <div class="col-12">
            <div class="card">
                <img class="card-img-top img-fluid" src="<?php echo site_url() ?>uploads/<?php echo $form_value->post_image ?>"  style=""alt="Card image cap">
                <div class="card-body">
                    <h4 class="card-title"><?php echo $form_value->post_title ?></h4>

                    <p class="card-text"><?php echo $form_value->post_content ?></p>
                </div>
                <div class="card-footer">
                  <p class="card-text">
                    <sub><?php echo $form_value->post_date; ?></sub><br>
                    Author: <?php echo $form_value->user_name; ?></p>
                </div>
            </div>
          </div>
        </div>


    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <?php $this->load->view('admin/footer'); ?>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
