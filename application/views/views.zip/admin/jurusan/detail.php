<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 col-8 align-self-center">
                <h3 class="text-themecolor">Jurusan</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo $parent ?>">Jurusan</a></li>
                    <li class="breadcrumb-item active">Tambah</li>
                </ol>
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                  <h4 class="card-title">Silahkan Masukan Data Jurusan</h4>

                  <form class="form-material m-t-40">
                      <div class="form-group">
                          <label>Nama Jurusan</label>
                          <input type="text" disabled name="jurusan_name" class="form-control form-control-line" autofocus> </div>

                      <div class="form-group">
                          <label>Yang Di Pelajari</label>
                          <textarea disabled name="jurusan_learn"class="form-control" rows="5"></textarea>
                      </div>
                      <div class="form-group">
                          <label>Kampus Favorit</label>
                          <textarea disabled name="jurusan_college"class="form-control" rows="5"></textarea>
                      </div>

                      <div class="form-group">
                          <label>Pekerjaan</label>
                          <textarea disabled name="jurusan_job"class="form-control" rows="5"></textarea>
                      </div>

                      <div class="form-group">
                          <label>Tipe</label>
                          <select disabled name="tipekarir_id" class="form-control">
                              <?php foreach ($tipekarir as $key => $value): ?>
                                <option value="<?php echo $value->tipekarir_id ?>"><?php echo $value->tipekarir_name ?></option>
                              <?php endforeach; ?>
                          </select>
                      </div>



                      <div class="form-group">

                      </div>
                  </form>
              </div>
            </div>
          </div>
        </div>


    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <?php $this->load->view('admin/footer'); ?>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->

<?php $this->load->view('admin/script_edit'); ?>
