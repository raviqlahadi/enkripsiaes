<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 col-8 align-self-center">
                <h3 class="text-themecolor">Jurusan</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active">Jurusan</li>
                </ol>
            </div>
            <div class="col-md-7 col-4 align-self-center">
                <div class="d-flex m-t-10 justify-content-end">
                    <div class="d-flex m-r-20 m-l-10 hidden-md-down">
                        <div class="chart-text m-r-10">
                            <a href="<?php echo site_url('admin/jurusan/create');?>" class="btn btn-primary" name="button">Tambah Jurusan</a>
                        </div>

                    </div>

                </div>
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
          <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if (isset($status)): ?>
                      <div class="alert alert-<?php echo $status['type']; ?>"> <i class="ti-jurusan"></i> <?php echo $status['message'] ?>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                      </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Nama Jurusan</th>
                                    <th>Tipe</th>
                                    <th>Image</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php if ($data==null): ?>
                                <h1>Data Tidak Di Temukan</h1>
                              <?php else: ?>


                              <?php foreach ($data as $key => $value): ?>
                                <tr>
                                    <td><?php echo $value->jurusan_name ?></td>
                                    <td><?php echo $value->tipekarir_name ?></td>
                                    <td><img style="height:100px;width:auto" src="<?php echo base_url('uploads/jurusan/'.$value->jurusan_image) ?>"></td>
                                    <td>
                                      <a href="<?php echo site_url('admin/jurusan/detail?id='.$value->jurusan_id)?>" class="btn btn-sm btn-secondary"><i class="fa fa-list"></i> </a>
                                      <a href="<?php echo site_url('admin/jurusan/edit?id='.$value->jurusan_id)?>" class="btn btn-sm btn-secondary"><i class="fa fa-edit"></i> </a>
                                      <a href="<?php echo site_url('admin/jurusan/delete?id='.$value->jurusan_id)?>" onclick="return confirm('Anda Yakin Akan Menghapus  ini?')" class="btn btn-sm btn-secondary"><i class="fa fa-trash"></i> </a>

                                    </td>
                                </tr>
                              <?php endforeach; ?>
                              <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
          </div>
        </div>


    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <?php $this->load->view('admin/footer'); ?>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
