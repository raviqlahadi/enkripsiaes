<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- User profile -->
        <div class="user-profile" style="background: url(<?php echo base_url()?>assets/admin/images/background/user-info.jpg) no-repeat;">
            <!-- User profile image -->
            <div class="profile-img"> <img src="<?php echo base_url()?>assets/admin/images/users/profile.png" alt="user" /> </div>
            <!-- User profile text-->
            <div class="profile-text"> <a href="#" class="dropdown-toggle u-dropdown" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">Markarn Doe</a>
                <div class="dropdown-menu animated flipInY"> <a href="#" class="dropdown-item"><i class="ti-user"></i> My Profile</a> <a href="#" class="dropdown-item"><i class="ti-wallet"></i> My Balance</a> <a href="#" class="dropdown-item"><i class="ti-email"></i> Inbox</a>
                    <div class="dropdown-divider"></div> <a href="#" class="dropdown-item"><i class="ti-settings"></i> Account Setting</a>
                    <div class="dropdown-divider"></div> <a href="login.html" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a> </div>
            </div>
        </div>
        <!-- End User profile text-->
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-small-cap">MENU</li>

                <li> <a class=" waves-effect waves-dark" href="<?php echo site_urL('admin/dashboard');?>" aria-expanded="false"><i class="mdi mdi-gauge"></i><span class="hide-menu">Dashboard </span></a>

                </li>
                <li> <a class="waves-effect waves-dark" href="<?php echo site_urL('admin/user');?>" aria-expanded="false"><i class="mdi mdi-account"></i><span class="hide-menu">User </span></a>

                </li>
                <li> <a class="waves-effect waves-dark" href="<?php echo site_url('admin/kuncikarir') ?>" aria-expanded="false"><i class="mdi mdi-key"></i><span class="hide-menu">Kunci Karir</span></a>

                </li>

                <li> <a class="waves-effect waves-dark" href="<?php echo site_url('admin/post') ?>" aria-expanded="false"><i class="mdi mdi-file-document"></i><span class="hide-menu">Post</span></a>

                </li>
                <li> <a class="waves-effect waves-dark" href="<?php echo site_url('admin/jurusan') ?>" aria-expanded="false"><i class="mdi mdi-domain"></i><span class="hide-menu">Jurusan</span></a>

                </li>

            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->

</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
