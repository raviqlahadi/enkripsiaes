<footer class="footer">
    © 2019 jurusanet
</footer>
