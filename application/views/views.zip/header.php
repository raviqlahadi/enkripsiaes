<div class="container">
  <nav class="navbar navbar-expand-lg">

    <a class="navbar-brand" href="<?php echo base_url()?>">
      <span class="logo-default">
        <img src="<?php echo base_url()?>assets/img/logo_default.png" alt="">
      </span>
      <span class="logo-inverse">
        <img src="<?php echo base_url()?>assets/img/logo_inverse.png" alt="">
      </span>
    </a>

    <button class="navbar-toggler p-0" data-toggle="collapse" data-target="#navbarNav">
            <div class="hamburger hamburger--spin js-hamburger">
                  <div class="hamburger-box">
                    <div class="hamburger-inner"></div>
                  </div>
              </div>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <?php if ($this->uri->segment(2)!=''): ?>
            <a class="nav-link" href="<?php echo site_url('home#features')?>">Fitur</a>

          <?php else: ?>
            <a class="nav-link" href="<?php echo site_url('home/')?>" data-scrollto="features">Fitur</a>
          <?php endif; ?>

        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('home/informasi')?>" >Informasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('home/jurusan')?>" >Jurusan</a>
        </li>
          <?php if ($this->session->userdata('user_level')==null): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('auth/login')?>">Login</a>
          </li>
          <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('home/profil')?>">Profil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('auth/logout')?>">Keluar</a>
          </li>
          <?php endif; ?>
        <li class="nav-item">
          <a class="nav-link btn btn-sm btn-rounded btn-green u-w-110" href="<?php echo base_url('kuncikarir')?>" >Kunci Karir</a>
        </li>
      </ul>
    </div>

  </nav>
</div> <!-- END container-->
