<!--
// ////////////////////////////////////////////////
// To Reduce server request and improved page speed drastically all third-party plugin bundle in assets/js/bundle.js
// If you wanna add those manually bellow is the sequence
// ///////////////////////////////////////////////
-->
<!--
<script src="<?php echo base_url()?>assets/vendor/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/popper.js/dist/popper.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/slick-carousel/slick/slick.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/fancybox/dist/jquery.fancybox.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/isotope/dist/isotope.pkgd.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/parallax.js/parallax.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/wow/dist/wow.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/vide/dist/jquery.vide.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/typed.js/lib/typed.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/appear-master/dist/appear.min.js"></script>
<script src="<?php echo base_url()?>assets/vendor/jquery.countdown/dist/jquery.countdown.min.js"></script>
<script src="<?php echo base_url()?>assets/js/smoothscroll.js"></script>
-->

<script src="<?php echo base_url()?>assets/js/bundle.js"></script>
<script src="<?php echo base_url()?>assets/js/fury.js"></script>
